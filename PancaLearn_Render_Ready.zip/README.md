# PancaLearn

**Interactive Pancasila Learning Platform**
> Belajar Pancasila. Pahami Nilainya. Terapkan dalam Kehidupan.

---

## 1. Project Overview

PancaLearn adalah platform pembelajaran Pancasila interaktif yang dirancang untuk mahasiswa dan pelajar Indonesia. Platform ini menggabungkan materi pembelajaran, studi kasus kehidupan nyata, quiz, sistem gamifikasi (XP, level, achievement, streak), Panca Challenge, serta AI Learning Assistant bernama **PancaAI**.

## 2. Project Goals

- Membuat pembelajaran Pancasila lebih modern, interaktif, dan menyenangkan.
- Menghubungkan teori Pancasila dengan penerapan nyata di kehidupan kampus dan digital.
- Memberikan pengalaman belajar seperti produk EdTech profesional.

## 3. Features

- 🏠 Homepage interaktif (hero, 5 sila, statistik, fitur, how it works, CTA, team)
- 📘 Materi Pancasila (5 materi + detail materi + mini quiz)
- 🧩 Studi Kasus (10 kasus penerapan nilai Pancasila)
- ❓ Quiz interaktif (10 soal, skor, XP, retry)
- ⚡ Sistem XP & Level (5 level, disimpan di localStorage)
- 🏆 Achievement (5 badge)
- 🔥 Learning Streak harian
- 🎯 Panca Challenge (harian & mingguan)
- 📊 Progress Dashboard
- 🤖 PancaAI — AI Learning Assistant (chat, quick prompts, context-aware)
- 🌙 Dark / Light mode
- 📱 Fully responsive (320px – 1440px)

## 4. Tech Stack

**Frontend:** HTML5, CSS3 (custom design system with CSS variables), Vanilla JavaScript
**Backend:** Node.js, Express.js
**AI:** Anthropic API, called only from the backend (`/api/ai`)
**Storage:** Browser `localStorage` for user progress & gamification state

## 5. Folder Structure

```text
PancaLearn/
├── frontend/
│   ├── index.html
│   ├── pages/            # materi, detail-materi, studi-kasus, quiz, challenge, progress, pancai
│   ├── css/               # one stylesheet per page/section + shared style.css
│   ├── js/                 # data.js (content), state.js (gamification engine), main.js (navbar/footer), per-page scripts
│   └── assets/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── routes/ai.js       # POST /api/ai — PancaAI endpoint
│   └── .env                # NOT committed — create from .env.example
├── .env.example
├── .gitignore
└── README.md
```

## 6. Installation

```bash
git clone <repo-url>
cd PancaLearn
cd backend
npm install
```

## 7. Environment Setup

Copy the example env file and fill in your AI API key:

```bash
cp ../.env.example .env
```

Edit `backend/.env`:

```env
AI_API_KEY=your_api_key_here
AI_MODEL=claude-sonnet-4-6
PORT=3000
```

**Never commit `.env` to git** — it is already listed in `.gitignore`.

## 8. Running the App

The backend serves both the API and the static frontend, so you only need one command:

```bash
cd backend
npm start
```

Then open your browser at:

```text
http://localhost:3000
```

> Note: If `AI_API_KEY` is not set, PancaAI will still respond with a graceful fallback message so the rest of the app can be demonstrated without a live API key.

## 9. PancaAI Setup

- Endpoint: `POST /api/ai`
- Request body: `{ "message": "...", "history": [...], "context": "..." }`
- Response: `{ "reply": "..." }`
- The system prompt keeps PancaAI focused strictly on Pancasila-related topics.
- The API key is read from `process.env.AI_API_KEY` inside `backend/routes/ai.js` and is **never** exposed to the frontend.

## 10. LocalStorage

PancaLearn stores the following under the key `pancalearn_state_v1`:

```text
userName, xp, completedMaterials, completedCases, quizScores,
challengeProgress, completedChallenges, achievements, streak, theme,
dailyLog, weeklyLog
```

Chat history for PancaAI is kept separately in `sessionStorage` (cleared when the tab closes) so conversations stay fresh per session.

## 11. Team Members

| Name | Role |
|---|---|
| Agil Dwi Pratama | Frontend Developer |
| Dominico Jose Wibowo | UI/UX Designer |
| Muhammad Syaeppuddin | Content & Research |
| Muhammad Mukhtasor Jidan | AI / Backend Developer |
| Soutan Maulana Alfarizi | QA / Tester |

## 12. Academic Information

- **Mata Kuliah:** Pancasila
- **Program Studi:** Teknik Informatika
- **Tahun:** 2026

## 13. Project Purpose

PancaLearn dibuat untuk memenuhi tugas mata kuliah Pancasila sebagai proyek edukatif yang menunjukkan penerapan teknologi web modern (frontend, backend, dan AI) untuk mendukung pembelajaran nilai-nilai kebangsaan.

---

© 2026 PancaLearn — Educational Project, Teknik Informatika.

## 12. Deploy ke Render

PancaLearn dapat dijalankan sebagai satu Render Web Service karena backend Express juga menyajikan folder `frontend`.

- Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`
- Environment Variable: `AI_API_KEY` (isi di Render, jangan di-commit)
- Environment Variable: `AI_MODEL` (opsional, default `claude-sonnet-4-6`)

File `render.yaml` di root project juga disediakan sebagai referensi konfigurasi deployment.
